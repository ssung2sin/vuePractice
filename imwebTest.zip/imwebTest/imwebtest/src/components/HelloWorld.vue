<template>

<div class="content-wrapper">
    <div class="main-title">
      <p class="header-text">Knowledge Base의 가치를 AI로 높이세요</p>
        <h1>기업 전용 차세대 생성을 AI챗봇 서비스</h1>
    </div>
    <div class="sub-title">
        <h2>AI Chatbot Solution</h2>
    </div>
    <div class="description">
        <p>애니톡은 생성형 AI 솔루션을 활용하여, 기업 문서 활용, 음성 대화, 맞춤 정보 제공, 글로벌 소통 등을 지원합니다.</p>
        <p>대화를 통해 스스로 학습하는 애니톡과 함께 당신의 비즈니스를 더욱 스마트하게 만들어 보세요.</p>
    </div>
    <div class="cta-button">
        <a href="https://anytalk.com" class="button">지금 바로 대화하기</a>
    </div>
</div>


<main> 		 	 			 		 		 	 			 		 		 	 			 		 		 	 			 		 		 	 			 		 		 	 			 		 		 	 			 		
  <div class="widget padding" data-height="50" style="margin-top:0px; margin-bottom:0px;">
	<div id="padding_w202408287c51165bcdb6d" style="width:100%; min-height:1px; height:100px; "></div>
</div>

		
				<div class="text-table "><div><p style="text-align: center;"><span style="font-size: 26px;"><strong><span style="color: rgb(13, 120, 104);">About</span></strong></span></p></div></div>		
<div class="_widget_data _ds_animated_except" data-widget-name="여백" data-widget-type="padding"    data-widget-parent-is-mobile="Y"><div class="widget padding" data-height="9" style="margin-top:px; margin-bottom:px;">
	<div id="padding_w20240905ce474da00dc06" style="width:100%; min-height:1px; height:9px; "></div>
</div>
</div>

		
				<div class="text-table ">
          <div>
            <p style="text-align: center;">
              <span style="color: rgb(141, 141, 147); font-size: 26px;">
                <strong>불편하고 비합리적인</strong>
              </span>
            </p>
            <p style="text-align: center;">
              <span style="font-size: 26px;">
                <span style="color: rgb(141, 141, 147);">
                  <strong>AI 서비스를 혁신하기 위해</strong>
                </span>
              </span>
            </p>
            <p style="text-align: center;">
              <span style="color: rgb(141, 141, 147); font-size: 26px;">
                <strong>출발했습니다</strong>
              </span>
            </p>
          </div>
        </div>		
	
<div class="widget padding" data-height="40" style="margin-top:0px; margin-bottom:0px;">
	<div id="padding_w202409056ed97e80e0e5c" style="width:100%; min-height:1px; height:40px; "></div>
</div>
  <table class="layout-table">
  <tr>
    <td rowspan="3" class="image-cell">
      <img src="https://cdn.imweb.me/thumbnail/20240903/c71babe6a22e3.png" alt="이미지">
    </td>
    <td class="text-cell">
      <p>쌓여있는 기업 문서를 더욱 효과적으로</p>
      <p>활용하세요</p>
    </td>
  </tr>
  <tr>
    <td class="text-cell">
      <p>데이터는 많지만 활용하기 어려운 기업 문서, B2B 생성형 AI 플랫폼으로 빠르게 찾고 똑똑하게 활용해보세요. '프로젝트 진행 상황 분석', '특정 사업의 참고 보고서 검색' 등 더 빠르고 효율적으로 업무를 처리할 수 있습니다.</p>
    </td>
  </tr>
  <tr>
    <td class="text-cell">
      <a href="https://anytalk.com" target="_blank"><strong>기업 업무도우미 챗봇 신청하기 &gt;</strong></a>
    </td>
  </tr>
</table>




<div doz_type="row" doz_xdz="12" class="doz_row col-xdz col-xdz-12">
  <div doz_type="grid" doz_xdz="12" class="col-dz col-dz- col-xdz col-xdz-12">
    <div doz_type="widget" id="w202409059766a789841ac">
      <div class="_widget_data _ds_animated_except" data-widget-name="여백" data-widget-type="padding" data-widget-parent-is-mobile="Y">
        <div class="widget padding" data-height="28" style="margin-top:0px; margin-bottom:0px;">
          <div id="padding_w202409059766a789841ac" style="width:100%; min-height:1px; height:28px;"></div>
        </div>
      </div>
    </div>
  </div>
</div>

<div doz_type="row" doz_xdz="12" class="doz_row col-xdz col-xdz-12">
  <div doz_type="grid" doz_xdz="12" class="col-dz col-dz- col-xdz col-xdz-12">
    <div doz_type="widget" id="w2024090517596ab635d48">
      <div class="_widget_data animated wg_animated" data-widget-name="이미지" data-widget-type="image" data-widget-anim="fadeInUp" data-widget-anim-duration="0.9" data-widget-anim-delay="0" data-widget-parent-is-mobile="Y">
        <div class="widget image _image_wrap text_position_bottom hover_text_position_bottom visibility hover_image_hidden fix_height hover_img_hide">
          <!-- Add your image content here -->
        </div>
      </div>
    </div>
  </div>
</div>

<table class="layout-table">
  <!-- 첫 번째 행: 이미지와 첫 번째 텍스트 -->
  <tr>
    <td rowspan="3" class="image-cell">
      <img src="https://cdn.imweb.me/thumbnail/20240905/5d0e1c724ea6a.png" alt="이미지">
    </td>
    <td class="text-cell">
      <p style="font-size: 22px; color: #000;"><strong>똑똑한 답변, 간편한 지식 관리,</strong></p>
      <p style="font-size: 22px; color: #000;"><strong>스마트 콜센터</strong></p>
    </td>
  </tr>
  <!-- 두 번째 행: 설명 텍스트 -->
  <tr>
    <td class="text-cell">
      <p>콜센터의 반복 업무에 지치셨나요? 애니톡으로 자동화하여 상담사의 부담을 줄이세요. 상담사의 답변을 학습해 정확성을 높이고, AI 전문가 없이 지식 관리를 간편하게 합니다. 고객 만족도와 업무효율을 동시에 올려보세요.</p>
    </td>
  </tr>
  <!-- 세 번째 행: 링크 -->
  <tr>
    <td class="text-cell">
      <a href="https://anytalk.com" target="_blank"><strong><span style="font-size: 14px; color: #000;">민원 콜센터 홈페이지 챗봇 체험하기 &gt;</span></strong></a>
    </td>
  </tr>
</table>

<table class="layout-table">
  <!-- 첫 번째 행: 이미지와 첫 번째 텍스트 -->
  <tr>
    <td rowspan="3" class="image-cell">
      <img src="https://cdn.imweb.me/thumbnail/20240905/aaadcfa93b576.png" alt="이미지"/>
    </td>
    <td class="text-cell">
      <p style="font-size: 22px; color: #000;"><strong>공공 페이지에서 나에게 알맞는 정보를</strong></p>
      <p style="font-size: 22px; color: #000;"><strong>손쉽게 찾아보세요.</strong></p>
    </td>
  </tr>
  <!-- 두 번째 행: 설명 텍스트 -->
  <tr>
    <td class="text-cell">
      <p>애니톡은 AI 웹 크롤링 등 대량 데이터를 정제해 정확한 답변을 제공합니다. '송파구 거주, 26세 남자, 취업 지원사업은?' 등 맞춤형 답변이 가능합니다. 정보를 빠르게 검색하고 제공하여 공공기관의 이미지와 서비스 품질을 높이세요.</p>
    </td>
  </tr>
  <!-- 세 번째 행: 링크 -->
  <tr>
    <td class="text-cell">
      <a href="https://anytalk.com" target="_blank">
        <strong><span style="font-size: 14px; color: #000;">공공 홈페이지 정보 검색 챗봇 체험하기 &gt;</span></strong>
      </a>
    </td>
  </tr>
</table>
<table class="layout-table">
  <!-- 첫 번째 행: 이미지와 첫 번째 텍스트 -->
  <tr>
    <td rowspan="3" class="image-cell">
      <img src="https://cdn.imweb.me/thumbnail/20240905/bd10afff60823.png" alt="이미지"/>
    </td>
    <td class="text-cell">
      <p style="font-size: 22px; color: #000;"><strong>음성대화부터 다국어 까지,</strong></p>
      <p style="font-size: 22px; color: #000;"><strong>소통의 장벽을 낮춰요</strong></p>
    </td>
  </tr>
  <!-- 두 번째 행: 설명 텍스트 -->
  <tr>
    <td class="text-cell">
      <p>STT/TTS로 음성 대화가 가능하고, 다국어 엔진으로 외국인도 쉽게 사용할 수 있습니다. 관광지 QR링크, 공공기관 로봇, 커피샵 키오스크, 그리고 다국적 기업에 활용해 보세요. 간편한 대화형 주문과 언어 장벽을 낮추고 글로벌 고객 경험을 향상시킵니다.</p>
    </td>
  </tr>
  <!-- 세 번째 행: 링크 -->
  <tr>
    <td class="text-cell">
      <a href="https://anytalk.com" target="_blank">
        <strong><span style="font-size: 14px; color: #000;">로봇,키오스크 다국어 지원 음성대화형 챗봇 체험하기 &gt;</span></strong>
      </a>
    </td>
  </tr>
</table>
	<div id="padding_w20240906e97411e253176" style="width:100%; min-height:1px; height:35px; "></div>
<div doz_type="row" doz_xdz="12" class="doz_row  col-xdz col-xdz-12"><div doz_type="grid" doz_xdz="12" class="col-dz col-dz-  col-xdz col-xdz-12"><div doz_type="widget" id="w202409056dae800d90ce0"><div class="_widget_data _ds_animated_except" data-widget-name="여백" data-widget-type="padding"    data-widget-parent-is-mobile="Y"><div class="widget padding" data-height="62" style="margin-top:0px; margin-bottom:0px;">
	<div id="padding_w202409056dae800d90ce0" style="width:100%; min-height:1px; height:62px; "></div>
</div>
</div></div></div></div></main>
<main> 		 	 			 		 		 	 			 		 		 	 			 		 		 	 			 		 		 	 			 		 		 	 			 		 		 	 			 		 		 	 			 		<div doz_type="row" doz_grid="12" class="doz_row"><div doz_type="grid" doz_grid="12" class="col-dz col-dz-12"><div doz_type="widget" id="w2024082852a955c587bb0"><div class="_widget_data " data-widget-name="가로선" data-widget-type="hr" data-widget-anim="none" data-widget-anim-duration="0.7" data-widget-anim-delay="0" data-widget-parent-is-mobile="N"><div class="widget line type01 _hide" id="hr_w2024082852a955c587bb0">
	<div class="line_box holder" style="width:100%; ">
		<hr style="border-top-width:1px; border-color:rgba(255, 255, 255, 0.1);" />	</div>
</div>

</div></div></div></div><div doz_type="inside" class="inside"><div doz_type="row" doz_grid="12" class="doz_row"><div doz_type="grid" doz_grid="12" class="col-dz col-dz-12"><div doz_type="widget" id="w202408283071ca040f594"><div class="_widget_data  animated wg_animated   " data-widget-name="텍스트" data-widget-type="text" data-widget-anim="fadeInUp" data-widget-anim-duration="0.9" data-widget-anim-delay="0" data-widget-parent-is-mobile="N">
	<div doz_type="text" class="widget _text_wrap widget_text_wrap fr-view  default_padding " id="text_w202408283071ca040f594" >
		
				<div class="text-table "><div><p style="text-align: center;"><span style="font-size: 48px;"><span style="color: rgb(13, 120, 104);"><strong>Main Service</strong></span></span></p></div></div>		
	</div>
	
</div></div></div></div><div doz_type="row" doz_grid="12" class="doz_row"><div doz_type="grid" doz_grid="12" class="col-dz col-dz-12"><div doz_type="widget" id="w202408288682e8b650e14"><div class="_widget_data  animated wg_animated   " data-widget-name="텍스트" data-widget-type="text" data-widget-anim="fadeInUp" data-widget-anim-duration="0.9" data-widget-anim-delay="0" data-widget-parent-is-mobile="N">
	<div doz_type="text" class="widget _text_wrap widget_text_wrap fr-view  default_padding " id="text_w202408288682e8b650e14" >
		
				<div class="text-table "><div><p style="text-align: center;"><span style="font-size: 60px;"><strong><span style="color: rgb(79, 79, 79);">AI로 더 빠르고 스마트하게,</span></strong></span></p><p style="text-align: center;"><br></p></div></div>		
	</div>
	
</div></div></div></div><div doz_type="row" doz_grid="12" class="doz_row"><div doz_type="grid" doz_grid="12" class="col-dz col-dz-12"><div doz_type="widget" id="w2024082859a3998765917"><div class="_widget_data  animated wg_animated   " data-widget-name="텍스트" data-widget-type="text" data-widget-anim="fadeInUp" data-widget-anim-duration="0.9" data-widget-anim-delay="0" data-widget-parent-is-mobile="N">
	<div doz_type="text" class="widget _text_wrap widget_text_wrap fr-view  default_padding " id="text_w2024082859a3998765917" >
		
				<div class="text-table "><div><p style="text-align: center;"><span style="font-size: 60px;"><strong><span style="color: rgb(79, 79, 79);">고객 경험을 새롭게 설계하다.</span></strong></span></p></div></div>		
	</div>
	
</div></div></div></div><div doz_type="row" doz_grid="12" class="doz_row"><div doz_type="grid" doz_grid="12" class="col-dz col-dz-12"><div doz_type="widget" id="w20240828f74f3a67b76aa"><div class="_widget_data _ds_animated_except" data-widget-name="여백" data-widget-type="padding"    data-widget-parent-is-mobile="N"><div class="widget padding" data-height="64" style="margin-top:0px; margin-bottom:0px;">
	<div id="padding_w20240828f74f3a67b76aa" style="width:100%; min-height:1px; height:64px; "></div>
</div>
</div></div></div></div></div></main>
<main> 		 	 			 		 		 	 			 		 		 	 			 		 		 	 			 		<div doz_type="inside" class="inside"><div doz_type="row" doz_xdz="12" class="doz_row  col-xdz col-xdz-12"><div doz_type="grid" doz_xdz="12" class="col-dz col-dz-  col-xdz col-xdz-12"><div doz_type="widget" id="w20240905af6c138c463a7"><div class="_widget_data _ds_animated_except" data-widget-name="여백" data-widget-type="padding"    data-widget-parent-is-mobile="Y"><div class="widget padding" data-height="30" style="margin-top:px; margin-bottom:px;">
	<div id="padding_w20240905af6c138c463a7" style="width:100%; min-height:1px; height:30px; "></div>
</div>
</div></div></div></div><div doz_type="row" doz_xdz="12" class="doz_row  col-xdz col-xdz-12"><div doz_type="grid" doz_xdz="12" class="col-dz col-dz-  col-xdz col-xdz-12"><div doz_type="widget" id="w2024090518a3814e759a2"><div class="_widget_data  animated wg_animated   " data-widget-name="이미지" data-widget-type="image" data-widget-anim="fadeInUp" data-widget-anim-duration="0.9" data-widget-anim-delay="0" data-widget-parent-is-mobile="Y"><div class="widget image  _image_wrap text_position_bottom hover_text_position_bottom visibility hover_image_hidden hover_img_hide   ">
	<div id="caption_w2024090518a3814e759a2" style="display:none"><h4></h4></div>
  <table class="layout-table">
  <!-- 첫 번째 행: 이미지와 첫 번째 텍스트 -->
  <tr>
    <td rowspan="4" class="image-cell">
      <img src="https://cdn.imweb.me/upload/S20240828fe9ca0917eae1/5a4f92f2cdd47.jpg" alt="이미지" />
    </td>
    <td class="text-cell">
      <p style="text-align: center; font-size: 20px; color: #828282;"><strong>AI로 지식을 더 똑똑하게</strong></p>
    </td>
  </tr>
  <!-- 두 번째 행: 두 번째 텍스트 -->
  <tr>
    <td class="text-cell">
      <p style="text-align: center; font-size: 30px; color: #4f4f4f;"><strong>휴먼지식 대화형 AI 성장</strong></p>
    </td>
  </tr>
  <!-- 세 번째 행: 리스트 -->
  <tr>
    <td class="text-cell">
      <ul>
        <li>실시간 휴먼전문가 연결 및 지식 요청 기능</li>
        <li>전문가 답변의 자동 학습 및 지식화 기능</li>
        <li>자율적 지식 확장 및 구성 기능</li>
        <li>지식 검증 및 업데이트 기능</li>
      </ul>
    </td>
  </tr>
</table>
	<div id="padding_w202409059ccf9ebbd5e2f" style="width:100%; min-height:1px; height:36px; "></div>
</div>
</div></div></div></div><div doz_type="row" doz_xdz="12" class="doz_row  col-xdz col-xdz-12"><div doz_type="grid" doz_xdz="12" class="col-dz col-dz-  col-xdz col-xdz-12"><div doz_type="widget" id="w202409055c929865a665d"><div class="_widget_data  animated wg_animated   " data-widget-name="이미지" data-widget-type="image" data-widget-anim="fadeInUp" data-widget-anim-duration="0.9" data-widget-anim-delay="0" data-widget-parent-is-mobile="Y"><div class="widget image  _image_wrap text_position_bottom hover_text_position_bottom visibility hover_image_hidden hover_img_hide   ">
	<div id="caption_w202409055c929865a665d" style="display:none"><h4></h4></div><table class="layout-table">
  <!-- 첫 번째 행: 이미지와 첫 번째 텍스트 -->
  <tr>
    <td rowspan="4" class="image-cell">
      <img src="https://cdn.imweb.me/upload/S20240828fe9ca0917eae1/92e47cf969ebc.jpg" alt="이미지"/>
    </td>
    <td class="text-cell">
      <p style="text-align: center; font-size: 20px; color: #828282;"><strong>기업용 AI 시스템 통합</strong></p>
    </td>
  </tr>
  <!-- 두 번째 행: 두 번째 텍스트 -->
  <tr>
    <td class="text-cell">
      <p style="text-align: center; font-size: 30px; color: #4f4f4f;"><strong>B2B 연계 AI 플랫폼</strong></p>
    </td>
  </tr>
  <!-- 세 번째 행: 리스트 -->
  <tr>
    <td class="text-cell">
      <ul>
        <li>B2B 시스템 연동 가능</li>
        <li>실시간 정보 수집 및 분석 기능</li>
        <li>대화형 인터페이스 지원 기능</li>
        <li>AI기반 워크 플로우 자동화 기능</li>
      </ul>
    </td>
  </tr>
</table>
	<div id="padding_w20240905506b478a68ac8" style="width:100%; min-height:1px; height:36px; "></div>
</div>
</div></div></div></div><div doz_type="row" doz_xdz="12" class="doz_row  col-xdz col-xdz-12"><div doz_type="grid" doz_xdz="12" class="col-dz col-dz-  col-xdz col-xdz-12"><div doz_type="widget" id="w20240905b376440c9cea0"><div class="_widget_data  animated wg_animated   " data-widget-name="이미지" data-widget-type="image" data-widget-anim="fadeInUp" data-widget-anim-duration="0.9" data-widget-anim-delay="0" data-widget-parent-is-mobile="Y"><div class="widget image  _image_wrap text_position_bottom hover_text_position_bottom visibility hover_image_hidden hover_img_hide   ">
	<div id="caption_w20240905b376440c9cea0" style="display:none"><h4></h4></div><table class="layout-table">
  <!-- 첫 번째 행: 이미지와 첫 번째 텍스트 -->
  <tr>
    <td rowspan="4" class="image-cell">
      <img src="https://cdn.imweb.me/upload/S20240828fe9ca0917eae1/0fed4a49e0c3a.jpg" alt="이미지" />
    </td>
    <td class="text-cell">
      <p style="text-align: center; font-size: 20px; color: #828282;"><strong>AI 로봇 소통 스마트</strong></p>
    </td>
  </tr>
  <!-- 두 번째 행: 두 번째 텍스트 -->
  <tr>
    <td class="text-cell">
      <p style="text-align: center; font-size: 30px; color: #4f4f4f;"><strong>로봇 음성 대화 지능 엔진</strong></p>
    </td>
  </tr>
  <!-- 세 번째 행: 설명 -->
  <tr>
    <td class="text-cell">
      <ul>
        <li>지능형 로봇 제어 인터페이스</li>
        <li>대화 연동 표준화 기능</li>
        <li>AI 정보 응답 시스템</li>
        <li>통합 디바이스 호환성 관리</li>
      </ul>
    </td>
  </tr>
</table>
	<div id="padding_w20240905fc32e3f85f4f4" style="width:100%; min-height:1px; height:36px; "></div>
</div>
</div></div></div></div>
	<div id="caption_w20240905b3367ae476a0c" style="display:none"><h4></h4></div><table class="layout-table">
  <!-- 첫 번째 행: 이미지와 첫 번째 텍스트 -->
  <tr>
    <td rowspan="4" class="image-cell">
      <img src="https://cdn.imweb.me/upload/S20240828fe9ca0917eae1/e5cdc65bfe8dc.jpg" alt="이미지" />
    </td>
    <td class="text-cell">
      <p style="text-align: center; font-size: 20px;"><strong>대화형 AI로 빠르게 주문, 만족도 상승</strong></p>
    </td>
  </tr>
  <!-- 두 번째 행: 두 번째 텍스트 -->
  <tr>
    <td class="text-cell">
      <p style="text-align: center; font-size: 30px; color: #4f4f4f;"><strong>키오스크 AI 메뉴 주문</strong></p>
    </td>
  </tr>
  <!-- 세 번째 행: 설명 -->
  <tr>
    <td class="text-cell">
      <ul>
        <li>대화형 주문 가이드 기능</li>
        <li>멀티언어 지원 가능</li>
        <li>비대면 결제 및 영수증 관리</li>
        <li>시각 장애인을 위한 음성 안내 기능</li>
      </ul>
    </td>
  </tr>
  <!-- 네 번째 행: 여백 -->
  <tr>
    <td class="padding-cell">
      <!-- 여백을 위한 공간 -->
    </td>
  </tr>
</table>
	<div id="padding_w20240905a33811af45dec" style="width:100%; min-height:1px; height:39px; "></div>
</div>

	<div doz_type="text" class="widget _text_wrap widget_text_wrap fr-view  default_padding " id="text_w202409054efc1221a8dce" >
		
				<div class="text-table "><div><p style="text-align: center;"><a class="btn" href="https://anytalk.com" style="border-radius: 9999px; background-color: #8d8d93; color: #f2f2f2; font-size: 15px; padding: 15px 24px; border: 0px solid;" target="_blank">지금 바로 대화하기</a></p></div></div>		
	</div>
	<div class="widget padding" data-height="56" style="margin-top:px; margin-bottom:px;">
	<div id="padding_w202409058904edc860e11" style="width:100%; min-height:1px; height:56px; "></div>
</div>
</main>
<main> 		 	 			 		
	<div id="padding_w20240828b37c6ebb6f9ba" style="width:100%; min-height:1px; height:72px; "></div>
	<div doz_type="text" class="widget _text_wrap widget_text_wrap fr-view  default_padding " id="text_w202408284cb8161c8d7e1" >
		
				<div class="text-table "><div><p style="text-align: center;"><span style="color: rgb(13, 120, 104); font-size: 24px;"><strong>Key Difference</strong></span></p></div></div>		
	</div>
	
	<div doz_type="text" class="widget _text_wrap widget_text_wrap fr-view  default_padding " id="text_w202408285ac81551e9ed5" >
		
				<div class="text-table "><div><p style="text-align: center;"><span style="color: rgb(79, 79, 79); font-size: 30px;"><strong>애니톡은 다릅니다.</strong></span></p></div></div>		
	</div>
	
	<div id="padding_w202408286fd530b5fe6b5" style="width:100%; min-height:1px; height:40px; "></div>
</main>
<div class="container1">
        <div class="features1">
            <div class="feature1">
              <img src="https://cdn.imweb.me/thumbnail/20240905/573960f038ae2.png" alt="" />
                <h3>다양한 데이터 자동분석</h3>
                <p>PDF, 엑셀, 도메인 기반 웹 수집 등 다양한 데이터를 분석해 답변을 제공합니다.</p>
            </div>
            <div class="feature1">
              <img src="https://cdn.imweb.me/thumbnail/20240905/d27c798e88fec.png" alt="" />
                <h3>글로벌 다국어 지원 가능</h3>
                <p>영어, 일본어, 중국어, 베트남어, 스페인어 등 다국어 지원으로 글로벌 고객과 소통합니다.</p>
            </div>
            <div class="feature1">
              <img src="https://cdn.imweb.me/thumbnail/20240905/17e9627a2057f.png" alt="" />
                <h3>조직 특화 LLM 솔루션 제공</h3>
                <p>업무 규약, 상품 설명 지침 등 조직 필요에 맞춘 최적의 AI 솔루션을 제공합니다.</p>
            </div>
            <div class="feature1">
              <img src="https://cdn.imweb.me/thumbnail/20240905/03370fd60a990.png" alt="" />
                <h3>맞춤형 서비스 설계</h3>
                <p>그룹웨어, ERP, CRM, MES 등 기업 상황과 목적에 따라 세부 기능 커스텀 개발 지원</p>
            </div>
        </div>
        <table class="features1-table">
            <thead>
                <tr>
                    <th>구분</th>
                    <th>애니톡</th>
                    <th>S사</th>
                    <th>M사</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>지식 성장 관리</td>
                    <td>직원이 직접 지식 보강</td>
                    <td>개발자 전문가 필요</td>
                    <td>개발자 전문가 필요</td>
                </tr>
                <tr>
                    <td>음성 대화 지원</td>
                    <td>음성으로 질문과 대답</td>
                    <td>X</td>
                    <td>X</td>
                </tr>
                <tr>
                    <td>다국어 지원 여부</td>
                    <td>영어, 일본어, 중국어 등</td>
                    <td>X</td>
                    <td>X</td>
                </tr>
                <tr>
                    <td>웹 수집 지원</td>
                    <td>도메인 기반 전체 웹 수집</td>
                    <td>X</td>
                    <td>X</td>
                </tr>
                <tr>
                    <td>B2B 연동 지원</td>
                    <td>GW, ERP, CRM 등</td>
                    <td>X</td>
                    <td>X</td>
                </tr>
                <tr>
                    <td>구축 방식</td>
                    <td>서비스 / 구축형</td>
                    <td>SI 구축</td>
                    <td>클라우드형</td>
                </tr>
                <tr>
                    <td>답변 속도</td>
                    <td>평균 1초 이내</td>
                    <td>약 3초 이내</td>
                    <td>약 3초 이내</td>
                </tr>
                <tr>
                    <td>보안 처리</td>
                    <td>G클라우드 보안 수준</td>
                    <td>X(해외 엔진 사용)</td>
                    <td>X</td>
                </tr>
            </tbody>
        </table>
    </div>

    <main> 		 	 			 		 		 	 			 		 		 	 			 		 		 	 			 		 		 	 			 		 		 	 			 		\
      <div class="line_box holder" style="width:100%; ">
		<hr style="border-top-width:1px; border-color:rgba(225, 225, 225, 0.5);" />	</div>

	<div id="padding_w20240828cbc09503ed235" style="width:100%; min-height:1px; height:120px; "></div>
	<div doz_type="text" class="widget _text_wrap widget_text_wrap fr-view  default_padding " id="text_w20240828ffeb769e5eee4" >
		
				<div class="text-table "><div><p style="text-align: center;"><span style="font-size: 48px;"><strong><span style="color: rgb(47, 148, 118);">Application Areas</span></strong></span></p></div></div>		
	</div>
	<div doz_type="row" doz_grid="12" class="doz_row"><div doz_type="grid" doz_grid="12" class="col-dz col-dz-12"><div doz_type="widget" id="w20240828ea97b5e52beec"><div class="_widget_data " data-widget-name="텍스트" data-widget-type="text" data-widget-anim="none" data-widget-anim-duration="0.9" data-widget-anim-delay="0" data-widget-parent-is-mobile="N">
	<div doz_type="text" class="widget _text_wrap widget_text_wrap fr-view  default_padding " id="text_w20240828ea97b5e52beec" >
		
				<div class="text-table "><div><p style="text-align: center;"><span style="font-size: 60px;"><strong><span style="color: rgb(79, 79, 79);">애니톡 활용 영역</span></strong></span></p></div></div>		
	</div>
	
</div></div></div></div><div doz_type="row" doz_grid="12" class="doz_row"><div doz_type="grid" doz_grid="12" class="col-dz col-dz-12"><div doz_type="widget" id="w20240828305c94acc1fca"><div class="_widget_data _ds_animated_except" data-widget-name="여백" data-widget-type="padding"    data-widget-parent-is-mobile="N"><div class="widget padding" data-height="64" style="margin-top:0px; margin-bottom:0px;">
	<div id="padding_w20240828305c94acc1fca" style="width:100%; min-height:1px; height:64px; "></div>
</div>
</div></div></div></div></main>

<main class="container2">
    <div class="card2">
        <h2>공공기관 및 지자체</h2>
        <h3>공공 서비스 최적화 및 민원 처리 자동화</h3>
        <p>공공기관의 민원, 포털 도우미 서비스 제공을 자동화하여 행정 효율성과 시민 만족도를 극대화하는 스마트 챗봇 솔루션 입니다.</p>
        <a href="https://anytalk.com" class="btn">더 보기</a>
    </div>
    <div class="card2">
        <h2>기업</h2>
        <h3>비즈니스 성과 향상과 효율적 운영 지원</h3>
        <p>고객 응대 시스템 최적화와 내부 업무 효율화로 기업 운영 성과를 극대화하는 맞춤형 솔루션 입니다.</p>
        <a href="https://anytalk.com" class="btn">더 보기</a>
    </div>
    <div class="card2">
        <h2>병원 및 학원</h2>
        <h3>병원 고객과 학생을 위한 스마트 솔루션</h3>
        <p>예약 시스템을 신속하고 정확하게 처리하며, 병원 업무 및 예약현황 관리와 학생들의 강의 상담과 일정표 관리를 강화합니다.</p>
        <a href="https://anytalk.com" class="btn">더 보기</a>
    </div>
    <div class="card2">
        <h2>로봇</h2>
        <h3>로봇과 연동된 지능형 자동화 서비스 제공</h3>
        <p>AI 로봇 솔루션으로 자동화된 고객 응대와 정보 제공을 실현해 인텔리전트한 비즈니스 환경을 구축합니다.</p>
        <a href="https://anytalk.com" class="btn">더 보기</a>
    </div>
    <div class="card2">
        <h2>키오스크</h2>
        <h3>무인 키오스크와의 통합 고객 경험 솔루션</h3>
        <p>키오스크에서 고객이 쉽게 정보를 탐색하고, 주문을 신속 처리하도록 지원해 고객 경험을 향상시킵니다.</p>
        <a href="https://anytalk.com" class="btn">더 보기</a>
    </div>
    <div class="card2">
        <h2>소상공인</h2>
        <h3>소상공인을 위한 맞춤형 고객 서비스 도우미</h3>
        <p>소상공인이 고객 응대와 정보 제공을 효과적으로 할 수 있도록 돕고, 매장 운영을 효율화하는 맞춤형 챗봇 솔루션입니다.</p>
        <a href="https://anytalk.com" class="btn">더 보기</a>
    </div>
</main>
<div id="padding_w20240828cbc09503ed235" style="width:100%; min-height:1px; height:120px; "></div>
<div class="container3">
    <h1>도입 방법</h1>
    <div class="card3">
        <h2>경제적 클라우드 방식</h2>
        <p>개인, 소상공인, 동호회, 기관, 아파트 단지 등 신청 후 즉시 사용</p>
    </div>
    <div class="card3">
        <h2>홈페이지 기업연동 방식</h2>
        <p>기업 B2B 시스템과의 연동 도입을 원하면</p>
    </div>
    <div class="card3">
        <h2>대규모 구축형 방식</h2>
        <p>자사 서비스에 애니톡을 도입하고 싶다면</p>
    </div>
</div>

<main>
    <div class="container4">
      <div class="header4">
        <div class="header4-box">
        <img src="https://cdn.imweb.me/upload/S20240828fe9ca0917eae1/59efa03f1c56c.png" alt="Logo" class="logo4">
        <h1>우리회사에 딱 맞는 AI, 애니톡을 만나보세요</h1>
        <p>애니톡에 대한 궁금한점을 질문해보세요!</p>
        <a class="btn4" href="https://anytalk.com" target="_blank">서비스 문의하기</a>
      </div>
        <img src="https://cdn.imweb.me/upload/S20240828fe9ca0917eae1/4376fe99391e9.png" alt="QR Code" class="qr-code4">
      </div>
    </div>
    <div class="footer4">
      <p>대표 : 최병진 | 주소 : 경기도 안양시 만안구 안양천로 93 새움소프트 사옥<br>사업자등록번호 : 138-81-25516</p>
      <div class="links4">
        <a href="https://template-5.imweb.me/?mode=privacy">개인정보 처리방침</a> |
        <a href="https://template-5.imweb.me/?mode=policy">이용약관</a> |
        <a href="https://imweb.me/">사업자 정보 확인</a>
      </div>
    </div>
    
</main>
</template>

<script>
export default {
  name: 'HelloWorld',
  props: {
    msg: String
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.first_bg{
  background-color: #f1f1f1;
    position: absolute;
    left: 0;
    top: 0;
    right: 0;
    bottom: 0;
}
.layout-table {
  width: 60%;
  border-collapse: collapse;
}

.layout-table td {
  padding: 20px;
  vertical-align: top;
}

.image-cell img {
  width: 600px;
  height: auto;
}

.text-cell {
  font-size: 22px;
  color: #000;
}

.text-cell p {
  margin: 0;
}

.text-cell a {
  font-size: 14px;
  color: #000;
  text-decoration: none;
}

.text-cell a:hover {
  text-decoration: underline;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Noto Sans', sans-serif;
    line-height: 1.6;
    background-color: #f9f9f9;
    color: #333;
}

/* 헤더 스타일 */
.header {
    background-color: #ffffff;
    padding: 20px 0;
    text-align: center;
}

.header img {
    width: 116px;
    height: auto;
}

/* 내비게이션 메뉴 */
.navbar {
    display: flex;
    justify-content: center;
    list-style: none;
    padding: 10px 0;
}

.navbar li {
    margin: 0 15px;
}

.navbar a {
    text-decoration: none;
    color: #333;
    font-weight: bold;
}

/* 메인 콘텐츠 스타일 */
.main-content {
    padding: 50px 20px;
    text-align: center;
}

.main-content h1 {
    font-size: 36px;
    color: #4f4f4f;
    margin-bottom: 20px;
}

.main-content p {
    font-size: 18px;
    color: #7d7d7d;
    margin: 10px 0;
}

/* 버튼 스타일 */
.btn {
    background-color: #8d8d93;
    color: #f2f2f2;
    padding: 15px 24px;
    border: none;
    border-radius: 9999px;
    font-size: 15px;
    text-decoration: none;
}

/* About 섹션 스타일 */
.about-section {
    background-color: #ffffff;
    padding: 40px 20px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    margin: 20px 0;
}

.about-section h2 {
    font-size: 30px;
    color: #0d7868;
    margin-bottom: 20px;
}

.about-section p {
    font-size: 18px;
    color: #8d8d93;
}

/* 이미지와 텍스트 테이블 스타일 */
.layout-table {
    width: 100%;
    margin: 20px 0;
    border-collapse: collapse;
}

.layout-table .image-cell {
    width: 50%;
    text-align: center;
}

.layout-table .text-cell {
    padding: 15px;
    width: 50%;
}

/* 반응형 스타일 */
@media (max-width: 768px) {
    .navbar {
        flex-direction: column;
    }

    .layout-table {
        display: block;
    }

    .layout-table .image-cell,
    .layout-table .text-cell {
        width: 100%;
        display: block;
    }
}

/* 스타일 테스트 */
.services-container {
    display: flex;
    justify-content: space-between;
    margin: 20px 0;
}

.service-item {
    flex: 1;
    margin: 0 10px;
    text-align: center;
}

.icon {
    margin-bottom: 10px;
}

.icon img {
    width: 50px; /* 아이콘 크기 조정 */
    height: auto;
}

h3 {
    font-size: 18px;
    color: rgb(79, 79, 79);
    margin: 10px 0;
}

p {
    font-size: 14px;
    color: #555; /* 텍스트 색상 조정 */
}

/* 제일 첫 스타일 */
.content-wrapper {
    text-align: center;
    padding: 40px;
    background-color: #f9f9f9;
}

.header-text {
    font-size: 12px;
    color: rgb(95, 95, 95);
    margin-bottom: 20px;
}

.main-title h1 {
    font-size: 30px;
    color: rgb(79, 79, 79);
    margin: 20px 0;
}

.sub-title h2 {
    font-size: 30px;
    font-weight: bold;
    color: rgb(51, 51, 51);
    margin: 20px 0;
}

.description p {
    color: rgb(79, 79, 79);
    font-size: 12px;
    line-height: 1.5;
    margin: 10px 0;
}

.cta-button {
    margin-top: 30px;
}

.button {
    border-radius: 9999px;
    background-color: #8d8d93;
    color: #f2f2f2;
    font-size: 15px;
    padding: 15px 24px;
    text-decoration: none;
}
/* 컨테이너1 */
.container1 {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}

.features1 {
    display: flex;
    justify-content: space-between;
    margin-bottom: 40px;
}

.feature1 {
    background-color: #f9f9f9;
    border-radius: 8px;
    padding: 20px;
    flex: 1;
    margin: 0 10px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    text-align: center;
}

.feature1 h3 {
    color: #333;
    font-size: 1.5em;
    margin-bottom: 10px;
}

.feature1 p {
    color: #666;
    font-size: 1em;
}

.features1-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

.features1-table th, .features1-table td {
    border: 1px solid #ddd;
    padding: 12px;
    text-align: center;
}

.features1-table th {
    background-color: #4CAF50;
    color: white;
}

.features1-table tr:nth-child(even) {
    background-color: #f2f2f2;
}

.features1-table tr:hover {
    background-color: #ddd;
}

.features1-table td {
    color: #333;
}

.features1-table td.X {
    color: #999;
}
.features1 img{
  width: 100px;
}

/*활용영역 */
.container2 {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            display: grid;
            grid-template-columns: repeat(3, 1fr); /* 3열로 설정 */
        }
        h2 {
            text-align: center;
            color: #4f4f4f;
            font-size: 24px;
            margin-bottom: 20px;
        }
        .features {
            display: flex;
            justify-content: space-around;
            margin-bottom: 30px;
        }
        .feature {
            text-align: center;
            flex: 1;
            margin: 0 10px;
        }
        .feature h3 {
            font-size: 18px;
            color: #4f4f4f;
        }
        .feature p {
            font-size: 14px;
            color: #666;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #4f4f4f;
            color: #fff;
        }
        .highlight {
            background-color: #eee;
        }
        /* */
        .container {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 20px;
    padding: 20px;
}

.card2 {
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    padding: 20px;
    margin: 20px;
    transition: transform 0.2s;
}

.card2 h2 {
    font-size: 24px;
    color: #2F9476;
    margin: 0 0 10px;
}

.card2 h3 {
    font-size: 20px;
    color: #000;
    margin: 0 0 10px;
}

.card2 p {
    font-size: 14px;
    color: #4D4D4D;
    line-height: 1.5;
}

.card2 .btn {
    display: inline-block;
    margin-top: 10px;
    padding: 10px 15px;
    background-color: #2F9476;
    color: #fff;
    text-decoration: none;
    border-radius: 5px;
    transition: background-color 0.3s;
}

.card2 .btn:hover {
    background-color: #238C5A;
}

.card2:hover {
    transform: translateY(-5px);
}

/* 도입방법 스타일 */
.container3 {
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
}

/* 제목 스타일 */
.container3 h1 {
    text-align: center;
    font-size: 36px;
    color: #333;
    margin-bottom: 30px;
}

/* 카드 스타일 */
.card3 {
    background-color: #f9f9f9;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

/* 카드 제목 스타일 */
.card3 h2 {
    font-size: 24px;
    color: #2f9a76;
    margin: 0 0 10px;
}

/* 카드 설명 스타일 */
.card3 p {
    font-size: 16px;
    color: #666;
    line-height: 1.5;
}

/* 문의하기 스타일 */
.container4 {
    background-color: white; /* 흰색 배경 */
    border-radius: 10px; /* 모서리 둥글게 */
    padding: 20px; /* 내부 여백 */
    max-width: 800px; /* 최대 너비 설정 */
    margin: 20px auto; /* 가운데 정렬 */
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); /* 그림자 효과 */
    display: flex; /* 플렉스 박스 사용 */
    align-items: center; /* 수직 정렬 */
    justify-content: space-between; /* 요소 간 간격 조정 */
}

.header4 {
    display: flex; /* 플렉스 박스 사용 */
    flex-direction: row; /* 가로 방향 정렬 */
    font-weight: bold;
    flex-grow: 1; /* 남은 공간 차지 */
    width: 70%; /* 70% 너비 */
    justify-content: space-between; /* 내부 요소 간 간격 조정 */
}

.header4-box {
    padding-right: 10px;
    flex-basis: 60%; /* 헤더 박스가 70%의 공간 차지 */
    flex-direction: column; /* 세로 방향 정렬 */
    text-align: left; /* 태그들을 좌측 정렬 */
}

.qr-code4 {
    width: auto;
    flex-basis: 40%; /* QR 코드가 30% 공간 차지 */
    max-width: 150px; /* QR 코드 크기 조절 */
    margin-left: 20px; /* 왼쪽 여백 */
}

.logo4{
    width: 150px; /* 로고 크기 조절 */
    margin-bottom: 5px; /* 아래 여백 */
}

.header4 h1 {
    font-size: 20px; /* 제목 크기 */
    font-weight: bold; /* 두껍게 */
    color: #000000; /* 제목 색상 */
    margin: 5px 0; /* 여백 */
}

.header4 p {
    font-size: 14px; /* 본문 크기 */
    color: #555; /* 본문 색상 */
    margin: 10px 0; /* 여백 */
}

.btn4 {
    background-color: #6c757d; /* 버튼 배경색 */
    color: white; /* 버튼 글자색 */
    padding: 10px 20px; /* 버튼 내부 여백 */
    border: none; /* 테두리 없음 */
    border-radius: 5px; /* 모서리 둥글게 */
    text-decoration: none; /* 밑줄 없음 */
    font-size: 14px; /* 버튼 글자 크기 */
    align-self: flex-start; /* 버튼을 위쪽에 정렬 */

}

.btn4:hover {
    background-color: #5a6268; /* 호버 시 색상 변화 */
}

.footer4 {
    text-align: center; /* 가운데 정렬 */
    padding: 10px 0; /* 위아래 여백 */
}

.links4 a {
    color: #007bff; /* 링크 색상 */
    text-decoration: none; /* 밑줄 제거 */
}

.links4 a:hover {
    text-decoration: underline; /* 호버 시 밑줄 추가 */
}

</style>
